# 氣象局api（天氣預報）

import requests
import json

my_token = "ageKGJgkRv00wgTPvOW8NteYmQJq2kNFcOPgIaAoKqF"
def line_notify_message(token, msg, sticker_id):

    headers = {
        "Authorization": "Bearer " + token, 
        "Content-Type" : "application/x-www-form-urlencoded"
    }

    payload = { 
        'message': msg, 
        'stickerPackageId': 789,
        'stickerId': sticker_id
    }
    r = requests.post("https://notify-api.line.me/api/notify", headers = headers, params = payload)
    return r.status_code

def getWeather(url):
  ret = requests.get(url)
  p = ret.text # json
  j = json.loads(p) # 將資料形成list
  return j

url = "https://opendata.cwb.gov.tw/api/v1/rest/datastore/F-C0032-001?Authorization=CWB-033073AD-EB41-4750-8A2B-E37A419119DA&locationName="
future_weather = getWeather(url)

tpe_dict = {}
for i in future_weather["records"]["location"]:
  if i['locationName'] == '臺北市':
    tpe_dict = i
#print(tpe_dict)

# 天氣狀況
weather = tpe_dict['weatherElement'][0]['time'][1]['parameter']['parameterName']
#print(weather)

# 降雨機率
PoP = tpe_dict['weatherElement'][1]['time'][1]['parameter']['parameterName']
#print(PoP)

# 最高/最低氣溫
max_temperature = tpe_dict['weatherElement'][4]['time'][1]['parameter']['parameterName']
min_temperature = tpe_dict['weatherElement'][2]['time'][1]['parameter']['parameterName']
#print(max_temperature, min_temperature)

# 體感
body_feeling = tpe_dict['weatherElement'][3]['time'][1]['parameter']['parameterName']
#print(body_feeling)

weather_teller_str = f"\n千喻女士早安：\n"
weather_teller_str += f"今日早上6點至傍晚6點的天氣狀況為{weather}，\n" 

weather_teller_str += f"最高溫為{max_temperature}度，最低溫為{min_temperature}度，"
if int(min_temperature) < 20: weather_teller_str += "很冷喔，要多穿一點！\n"

weather_teller_str += f"啊降雨機率是{PoP}趴，"
if int(PoP) > 0: weather_teller_str += "要記得帶傘嘿！\n"
else: weather_teller_str += "好天氣喔，讚啦，記得出去走走喔～\n"

weather_teller_str += "以上，祝你有美好的一天～"

if "雨" in weather: sticker_id = 10893
elif "晴" in weather: sticker_id = 10871
else: sticker_id = 10863
line_notify_message(my_token, weather_teller_str, sticker_id)

print(weather_teller_str)
