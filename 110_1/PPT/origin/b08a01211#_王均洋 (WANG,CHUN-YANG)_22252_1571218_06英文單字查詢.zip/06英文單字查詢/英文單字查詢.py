from selenium import webdriver
import time
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from docx import Document
from docx.shared import Inches
from docx.shared import Pt
from docx.oxml.ns import qn
from docx. shared import RGBColor
import re

#判斷中文
def is_contains_chinese(strs):
    for _char in strs:
        if '\u4e00' <= _char <= '\u9fa5':
            return True
    return False

def indent (p,x):
    p_format = p.paragraph_format
    p_format.left_indent = Inches(x)

def wr_ch (p):
    for run in p.runs:
        run.font.size = Pt(12)
def wr_en (p):
    for run in p.runs:
        run.font.size = Pt(14)
    
lineText = []
blueText = []
doc = Document ('./範例1.docx' )
for p in doc.paragraphs:
    for r in p.runs:
        if r.font.color.rgb == RGBColor (0, 112, 192):
            if r.font.underline:
                lineText.append (r.text)
            else:
                blueText.append (r.text)
        
result = {'blue text': blueText,
        'underline text': lineText}

document = Document()
document.styles['Normal'].font.name = 'Times New Roman'
document.styles['Normal']._element.rPr.rFonts.set(qn('w:eastAsia'), u'新細明體')

driver = webdriver.Chrome()

for i in blueText:
    p = document.add_paragraph(i, style='List Number')
    wr_en(p)
    
    driver.get("https://dictionary.cambridge.org/zht/%E8%A9%9E%E5%85%B8/%E8%8B%B1%E8%AA%9E-%E6%BC%A2%E8%AA%9E-%E7%B9%81%E9%AB%94/"+"%s"%i)
    a=driver.find_elements(By.CLASS_NAME,"def-block ddef_block".replace(" ","."))
    if a==[]:
        driver.get("https://dictionary.cambridge.org/zht/%E8%A9%9E%E5%85%B8/%E8%8B%B1%E8%AA%9E/"+"%s"%i)
        a=driver.find_elements(By.CLASS_NAME,"def-block ddef_block".replace(" ","."))
        no_ch=1
        if a==[]:
            continue
    else:
        no_ch=0
    
    for j in range(len(a)):
        Sep=[]
        Sep=a[j].text.split("\n")
        first_ch=0
        first_en=0
        l=0
        for k in range(len(Sep)): 
            if no_ch==0:
                if is_contains_chinese(Sep[k]) == True :
                    p = document.add_paragraph(Sep[k])
                    wr_ch(p)
                    if first_ch==0:
                        first_ch=1                        
                        indent (p,0.5)
                    else:
                        indent (p,1)
                else:
                    if len(Sep[k])!=2:
                        if first_ch==0:
                            if first_en==0:
                                p = document.add_paragraph(Sep[k], style='List Bullet')
                                wr_en(p)
                                indent (p,0.5)
                                first_en+=1
                            else:
                                run=p.add_run(' '+Sep[k])
                                run.font.size = Pt(14)
                        else:
                            p = document.add_paragraph(Sep[k], style='List Bullet')
                            wr_en(p)
                            indent (p,1)
            else:
                m =[]
                m =Sep[k].split(" ")
                if m[0].isupper() == False and Sep[k]!="formal"and Sep[k]!="informal":
                    p = document.add_paragraph(Sep[k], style='List Bullet')
                    wr_en(p)
                    if l==0:
                        indent (p,0.5)
                        l+=1
                    else:
                        indent (p,1)
                if m[0].isupper() == True and len(m[0])==1:
                    p = document.add_paragraph(Sep[k], style='List Bullet')
                    wr_en(p)
                    if l==0:
                        indent (p,0.5)
                        l+=1
                    else:
                        indent (p,1)
#######
def del_Objectives(w):
    d=["me","us","you","him","her","it","them","myself","ourselves","yourself","yourselves","himself","herself","itself","themselves"]
    ww=w.split(" ")
    for i in d:
      for j in ww:
        if i in ww:
          ww.remove(i)
          return " ".join(ww)


def distinguish_single_multiple(a):
    if "1." in a:
      p = document.add_paragraph(a.split("\n")[0], style='List Number')
      wr_en(p)
      r=num_sep(a)
      for i in range(len(r)):
        for j in range(len(r[i])):
          if j==0:
            z=r[i][j].split(" ")
            del z[0]
            z=" ".join(z)
            match_result=re.match(r'(.*?)[A-Z]', z,re.S)
            word=match_result.group(1).strip()
            if word != "":
              z="(%s) "%word + z.lstrip(word)
            q = document.add_paragraph(z, style='List Bullet')
            wr_en(q)
            indent (q,0.5)
          else:
            q = document.add_paragraph(r[i][j], style='List Bullet')
            wr_en(q)
            indent (q,1)
    else:
      a=a.split("\n")
      p = document.add_paragraph(a[0], style='List Number')
      wr_en(p)
      
      for i in range(1,len(a)):
        q = document.add_paragraph(a[i], style='List Bullet')
        wr_en(q)
        if i==1:
            indent (q,0.5)
        else:
            indent (q,1)

def num_sep(p):
  count=[]
  f=[]
  p=p.split("\n")
  for i in range(len(p)):
    if p[i][0].isdigit():
      count.append(i)
 
  for j in range(len(count)):
    if j == len(count)-1:
      short=[]
      for l in range(count[j],len(p)):
        short.append(p[l])
      f.append(short)
    else:
      short=[]
      for k in range(count[j],count[j+1]):
        short.append(p[k])
      f.append(short)
  return(f)

lineTextWithoutO=[]
for withO in lineText:
  if del_Objectives(withO)==None:
    lineTextWithoutO.append(withO)
  else:
    lineTextWithoutO.append(del_Objectives(withO))
for s in lineTextWithoutO:
  driver.get("https://idioms.thefreedictionary.com/"+"%s"%s) 
  try:
    Eng_def=driver.find_element(By.CSS_SELECTOR,"#Definition > section:nth-child(1)")
  except:
    try:
        Eng_def=driver.find_element(By.CSS_SELECTOR,"#Definition > section:nth-child(3)")
    except:
      p = document.add_paragraph(s, style='List Number')
      wr_en(p)
      pass
      continue
  a=re.split("\nSee also:.*\s",Eng_def.text)
  a.pop()
  for t in range(len(a)):
    distinguish_single_multiple(a[t])


            
        
document.save('單字表.docx')   

