
import requests
from bs4 import BeautifulSoup

httpKey = "https://www.ptt.cc/" 
ptt_headers = {'cookie': 'over18=1;'}                                       
r = requests.get("https://www.ptt.cc/bbs/movie/index.html" , headers = ptt_headers ) 
# 轉文字
soup = BeautifulSoup(r.text,"html.parser") 
sel = soup.select("div.title a") 
#印標題
for s in sel:
    print( httpKey +  s["href"], s.text) # 要連結

# 上頁
next = "" ;
for d in range( 1 , 5 ) :
    sel = soup.select("div.btn-group a")
    next = None ;
    for dd in sel :
        if  "上頁" in dd.text:
            next = dd["href"] ;
            break ;
    # 沒有上一頁
    if( next == None ):
        print( " >> not next page " );
        break ;
    # 有上一頁
    print( ' >> next page:' , next );

    # 重抓一次網頁
    r = requests.get("https://www.ptt.cc" + next , headers = ptt_headers)
    soup = BeautifulSoup(r.text,"html.parser")
   # print( soup );

    sel = soup.select("div.title a") 
    for s in sel:
      print( httpKey + s["href"], s.text) 




