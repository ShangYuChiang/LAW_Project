import tkinter as tk
import random as re
from tkinter import ttk
from tkinter.constants import END


def check_winner_method():

    if playerGuessCnt < cnt:
        return 'You Win!'
    elif cnt < playerGuessCnt:
        return 'AI Wins!'

    else:
        return 'Tie Game!'

def guess_algorithm(guess, var):

    # 演算法
    tempSet = []
    amountA = var[0]
    amountB = var[1]

    for tempNum in universalSet:
        per = check_machine(tempNum, guess)

        if per[0] > amountA or per[1] > amountB:
            tempSet.append(tempNum)

    return tempSet

def ai_algorithm(code):

    global universalSet
    lst = []

    # 建立演算法的宇集
    universalSet = []
    for i in range(1, 10):
        for j in range(0, 10):
            if j != i:
                for m in range(0, 10):
                    if (m != j) and (m != i):
                        for n in range(0, 10):
                            if (n != m) and (n != j) and (n != i):
                                num = (i*1000 + j*100 + m*10 + n)
                                num = str(num)
                                universalSet.append(num)

    for i in range(1,10):
        for j in range(1, 10):
            if j != i:
                for m in range(1, 10):
                    if (m != j) and (m != i):
                        num = (i*100 + j*10 + m)
                        num = str(num).zfill(4)
                        universalSet.append(num)

    # 執行猜測
    global cnt
    cnt = 0
    while True:
        if cnt == 0:
            guess = "1234"
        elif cnt == 1:
            guess = "5678"

        else:
            guess = "".join(re.sample(universalSet, 1))

        var = check_machine(guess, code)
        cnt += 1

        if var[0] != 4:
            configVar = f"AI GUESS: {guess} --> HINT: {var[0]}A{var[1]}B!"
            universalSet = set(universalSet) - set(guess_algorithm(guess, var))
            universalSet = list(universalSet)
            lst.append(configVar)

        else:
            configVar = f"GOTCHA! IT'S {guess}~ TOTAL COUNTS: {cnt}"
            lst.append(configVar)
            break

    return lst




def result_config_method():

    input_ai_label = tk.Label(input_frame, text=f'您欲給電腦猜測的數字為： {code}')
    input_ai_label.pack(side=tk.LEFT)

    configList = ai_algorithm(code)

    for varStr in configList:
        configure_hint_method(varStr)

    winner = check_winner_method()
    configure_hint_method(winner)


def progress_method():

    # Progressbar running motion
    for i in range(5):
        pb['value'] += 20
        root.update_idletasks()

    root.after(1000, result_config_method)
    root.after(1000, lambda: root.destroy())


def progress_bar_widget():

    global pb
    global root
    global code

    # 毀滅機制
    code = input_1_entry.get()
    window_4.destroy()

    # 模擬電腦解題中
    root = tk.Tk()
    root.title('Calculating...')
    root.geometry('300x120')

    # Progress Bar
    pb = ttk.Progressbar(root,
                         orient='horizontal',
                         mode='determinate',
                         length=280
                        )
    pb.pack(expand=True)
    pb.after(1000, progress_method)

    root.mainloop()


def input_tkinter_method():

    global playWithAiBool
    playWithAiBool = True

    # 毀滅機制
    window_2.destroy()

    # 製作使用者輸入欲給電腦猜測數字的視窗
    global window_4
    global input_1_entry

    window_4 = tk.Tk()
    window_4.title('')
    window_4.geometry('400x200')

    header_3_label = tk.Label(window_4, text='請輸入欲給電腦猜的數字： ', font=('', 15))
    header_3_label.place(x=0, y=60)  # mac: (x,y) = (10,60) ; windows (x,y) = (0, 60)

    input_1_entry = tk.Entry(window_4)
    input_1_entry.place(x=240, y=60) # mac: (x,y) = (200,60) ; windows (x,y) = (240,60)

    submit_btn = tk.Button(window_4, text='Submit', height=2, width=10, command=progress_bar_widget)
    submit_btn.place(x=155, y=100)

    window_4.mainloop()



def end_game_method():

    # 整個程式結束
    window.destroy()
    window_3.destroy()


def restart_tkinter_method():

    # 毀滅機制
    window_2.destroy()

    # 製作不挑戰電腦後之彈出視窗
    global window_3

    window_3 = tk.Tk()
    window_3.title('')
    window_3.geometry('400x200')

    header_2_label = tk.Label(window_3, text='Do you want to restart?', font=('', 20))
    header_2_label.place(x=90, y=50)

    sure_btn = tk.Button(window_3, text='Absolutely', height=2, width=10, command=refresh_method)
    sure_btn.place(x=100, y=100)

    refusal_btn = tk.Button(window_3, text='Next Time', height=2, width=10, command=end_game_method)
    refusal_btn.place(x=200, y=100,)

    window_3.mainloop()

def gotcha_method():

    global window_2

    # 製作使用者猜到數字後之彈出視窗
    window_2 = tk.Tk()
    window_2.title('')
    window_2.geometry('400x200')

    header_1_label = tk.Label(window_2, text='Do you want to challenge the SUPER AI?', font=('', 15))
    header_1_label.place(x=60, y=50)

    yes_btn = tk.Button(window_2, text='Yes', height=2, width=10, command=input_tkinter_method)
    yes_btn.place(x=100, y=100)

    no_btn = tk.Button(window_2, text='No', height=2, width=10, command=restart_tkinter_method)
    no_btn.place(x=200, y=100)

    window_2.mainloop()


def configure_hint_method(Str):

    # 製作提示輸出區域
    hint_label = tk.Label(window)
    hint_label.pack()

    hint_label.configure(text=Str)

    # 使用者是否已經猜到數字
    if gotchaBool and not playWithAiBool:
        gotcha_method()


def game_mainloop():

    global playerGuessCnt
    global gotchaBool
    global playWithAiBool

    playerGuessCnt += 1
    gotchaBool = False
    playWithAiBool = False
    guessNumber = input_entry.get()
    input_entry.delete(0, END)  # 刷新輸入欄位
    hintTuple = check_machine(guessNumber, answerCode)

    if hintTuple[0] != 4:
        defaultStr = f'YOUR GUESS: {guessNumber}'
        hintStr = f'HINT: {hintTuple[0]}A{hintTuple[1]}B!'
        configureStr = f'{defaultStr} --> {hintStr}'

    else:
        configureStr = f"GOTCHA! IT'S {guessNumber}~ TOTAL TRIES: {playerGuessCnt}"
        gotchaBool = True

    configure_hint_method(configureStr)



def check_machine(check, code):

    # 檢查幾a幾b
    countA = 0
    countB = 0

    for number in check:
        if number in code:
            if check.index(number) == code.index(number):
                countA += 1
            else:
                countB += 1

    return (countA, countB)


def answer_random_maker():

    # 自動生成欲猜測的四位數字
    nums = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
    answer = "".join(re.sample(nums, 4)) # 不重複的四位數字

    return answer


def refresh_method():

    try:
        if window_3.state() == 'normal':
            window_3.destroy()
            window.destroy()
            tkinter_mainloop()

    except:
        # 重新開始
        window.destroy()
        tkinter_mainloop()


def config_answer_method():

    answer_label = tk.Label(input_frame, text=f'reference answer: {answerCode}')
    answer_label.pack(side=tk.BOTTOM)


def tkinter_mainloop():

    # 初始化設定
    global window
    global answerCode
    global playerGuessCnt
    global input_frame

    window = tk.Tk()
    window.title('1A2B GAME APP')
    window.geometry('800x600') # 全螢幕--560x1600
    answerCode = answer_random_maker()
    playerGuessCnt = 0

    # 標題設定
    header_label = tk.Label(window, text='WELCOME TO 1A2B GAME!', font=('', 15))
    header_label.pack()

    # 模擬啟動
    loading_label = tk.Label(window, text='GAME LOADING...', font=('', 21))
    loading_label.pack()
    loading_label.after(3000, lambda: loading_label.destroy()) # 時間戳記為ms

    # 製作使用者輸入猜測數字欄位--上半部
    input_frame = tk.Frame(window)
    input_frame.after(3000, lambda: input_frame.pack(side=tk.TOP))
    input_label = tk.Label(input_frame, text='請輸入您的猜測： ')
    input_label.after(3000, lambda: input_label.pack(side=tk.LEFT))

    global input_entry

    input_entry = tk.Entry(input_frame)
    input_entry.after(3000, lambda: input_entry.pack(side=tk.LEFT))

    # 建立按鈕區域--下半部
    global bottom_frame
    bottom_frame = tk.Frame(window)
    bottom_frame.pack(side=tk.BOTTOM)

    # 建立提交按鈕
    enter_btn = tk.Button(bottom_frame, text='GUESS!', command=game_mainloop, height=3, width=20)
    enter_btn.pack(side=tk.LEFT)

    # 建立解答按鈕
    answer_btn = tk.Button(bottom_frame, text='ANSWER', command=config_answer_method, height=3, width=20)
    answer_btn.pack(side=tk.LEFT)

    # 建立重新開始按鈕
    restart_btn = tk.Button(bottom_frame, text='RESTART', command=refresh_method, height=3, width=20)
    restart_btn.pack(side=tk.LEFT)

    # 執行視窗程式
    window.mainloop()


tkinter_mainloop()