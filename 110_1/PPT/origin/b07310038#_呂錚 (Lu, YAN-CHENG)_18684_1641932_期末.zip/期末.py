import time
import requests
from bs4 import BeautifulSoup
from selenium import webdriver
prev_s1 = []
prev_s2 = []
while 1:
    
    url='https://law.judicial.gov.tw/default.aspx'
    '''
    driver = webdriver.Firefox(executable_path=r'D:\Download\geckodriver.exe')
    driver.get(url)

    html = driver.page_source
    soup = BeautifulSoup(html)
    print(soup)
    '''
    #url='https://law.judicial.gov.tw/LAW_MOBILE/default.aspx'
    #url='https://www.dcard.tw/f'
    r=requests.get(url)
    page=r.content.decode('utf-8')
    soup=BeautifulSoup(page, 'html5lib')
    i = 0
    while "Please enable JavaScript" in soup:
        print(i)
        i = i+1
        r=requests.get(url)
        page=r.content.decode('utf-8')
        soup=BeautifulSoup(page, 'html5lib')
        #print(soup)

    lines=soup.select("#TPSV_LATEST_LIST")  #抓最高法院民事
    lines1=soup.select("#TPSM_LATEST_LIST") #抓最高法院刑事

    #print(soup)

    s1 = []
    for li in lines:
        for text in li.text.split("\n"):
            if "最高法院" in text:
                s1.append(text.strip())
    for li1 in lines1:
        for text in li1.text.split("\n"):
            if "最高法院" in text:
                s1.append(text.strip())
    s2=[]
    for li in str(lines).split("\n"):
        try:
            start_pos = li.find("<li>") + len('<li><a href="')
            end_pos = li.find('">')
        except:
            pass
        if "FJUD" in li[start_pos : end_pos]:
            s2.append(li[start_pos : end_pos])
    for li1 in str(lines1).split("\n"):
        try:
            start_pos = li1.find("<li>") + len('<li><a href="')
            end_pos = li1.find('">')
        except:
            pass
        if "FJUD" in li1[start_pos : end_pos]:
            s2.append(li1[start_pos : end_pos])

    t = time.localtime()

    # 依指定格式輸出
    ftime = time.strftime("%m/%d/%Y, %H:%M:%S", t)
    print(ftime)

    #my_token = 'CYBPSttMhjk6HIl9D5YHuh9yVset8RWlbmZszV79Mn2'
    #my_token = 't0ax1Oz72gZdhsyMDCQCL9716arWkwieKuQGM9ZJCzg'
    my_token = 'qJVnYsmrhDz1NlF66xvx2dnqQueg6xZ6OMQEnE01sAB'
    def lineNotifyMessage(token, msg):

        headers = {
            "Authorization": "Bearer " + token, 
            "Content-Type" : "application/x-www-form-urlencoded"
        }

        payload = {'message': msg }
        r = requests.post("https://notify-api.line.me/api/notify", headers = headers, params = payload)
        return r.status_code

    
    for i in range(len(s1)):
        if s1[i] not in prev_s1:
            prev_s1.append(s1[i])
            prev_s2.append(s2[i])
            print(s1[i])
            print(s2[i])
            msg=s1[i] + '電腦版網址: ' + "https://law.judicial.gov.tw/" + s2[i] 
            lineNotifyMessage(my_token, msg)
            print('\n')

    time.sleep(86400)



