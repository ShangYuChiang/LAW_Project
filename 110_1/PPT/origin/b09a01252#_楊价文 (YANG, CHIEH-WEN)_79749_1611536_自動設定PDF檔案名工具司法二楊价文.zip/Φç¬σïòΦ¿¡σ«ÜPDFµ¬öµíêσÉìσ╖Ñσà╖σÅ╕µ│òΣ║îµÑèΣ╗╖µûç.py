import os
from pdf2image import convert_from_path,convert_from_bytes
from PIL import Image
import pytesseract
import tempfile
from pdf2image.exceptions import (
    PDFInfoNotInstalledError,
    PDFPageCountError,
    PDFSyntaxError
)
path=os.path.dirname(os.path.abspath(__file__))
items = os.listdir(path)
newlist = []
for names in items:
    if names.endswith(".pdf"):
        newlist.append(path+"/"+names)
def pdf2image2(pdfPath):
    with tempfile.TemporaryDirectory() as path:
        images_from_path = convert_from_path(pdfPath, output_folder=path, dpi=96,last_page=1)
        for image in images_from_path:
            image.save(pdfPath+'.png', 'PNG')
        return
for i in newlist:
  pdf2image2(i)
  img = Image.open(i+'.png')
  text = pytesseract.image_to_string(img, lang='chi_tra')
  new_file=text.replace('\n','').replace(' ','').replace(">",'').replace("<",'').replace("/",'')[0:10]
  O_path=i
  N_path=path+"/"+new_file
  os.rename(O_path,N_path)
  os.remove(i+'.png')