import requests
from bs4 import BeautifulSoup
import prettytable as pt
import googlemaps
import time
import sys
from re import findall
from openpyxl import Workbook
from openpyxl import load_workbook
from openpyxl.styles import PatternFill

gmaps = googlemaps.Client(key='AIzaSyDjQ7mkJXfMJmYrtjGPt0sRrn6SnTLR_Pk')

def layer(n):
    global location, results, direction, stores_name, stores_address, tds
    if n == 1:
        print('===== 歡迎使用 加油站資料查找 =====')
        print('※ 請輸入選項號碼')
        first = input('請選擇功能 ( 1. 油價查詢 / 2. 搜尋附近加油站 ): ')

        result = []
        oil_price = pt.PrettyTable()
        res = requests.get('https://www2.moeaboe.gov.tw/oil102/oil2017/A01/A0108/tablesprices.asp')
        res.encoding = 'big5'  # 網站是用big5 編碼
        soup = BeautifulSoup(res.text, 'lxml')
        table = soup.findAll("table", class_='rwd-table')[1]
        tds = table.find_all('td')
        if first == '1':
            for a in range(7):
                result.append(tds[a].text)
            oil_price.field_names = result
            result = []
            for i in range(2):
                for n in range(7):
                    result.append(tds[(i + 1) * 7 + n].text)
                oil_price.add_row(result)
                result = []
            oil_price.set_style(pt.MSWORD_FRIENDLY)
            print(oil_price)
            print('※※ 資料來源: 政府油價資訊管理與分析系統 https://www2.moeaboe.gov.tw/oil102/oil2017/A01/A0108/tablesprices.asp')
            layer(2)
        elif first == '2':
            layer(2)
        else:
            print('Error message!')
            layer(1)

    if n == 2:
        location = input('請輸入目前位置地址: ')
        results = []
        # Geocoding an address
        geocode_result = gmaps.geocode(location)
        loc = geocode_result[0]['geometry']['location']
        query_result = gmaps.places_nearby(keyword="加油站", location=loc, radius=1000)
        results.extend(query_result['results'])
        while query_result.get('next_page_token'):
            time.sleep(2)
            query_result = gmaps.places_nearby(page_token=query_result['next_page_token'])
            results.extend(query_result['results'])
        layer(3)

    if n ==3:
        ids = []
        print("找到以目前位置為中心半徑1000公尺的加油數量(google mapi api上限提供60間): " + str(len(results)))
        if len(results) != 0:
            for place in results:
                ids.append(place['place_id'])
            ids = list(set(ids))

            stores_name = []
            stores_address = []
            for id in ids:
                stores_info = gmaps.place(place_id=id, language='zh-TW')['result']
                stores_name.append(stores_info['name'])
                stores_address.append(stores_info['formatted_address'])
                print(stores_info['name']+'  ', end='')
                try:
                    print(stores_info['formatted_phone_number']+'  ', end='')
                except:
                    pass
                try:
                    if(stores_info['opening_hours']['open_now'] == True):
                        print('( 營業中 )')
                    else:
                        print('( 非營業時段 )')
                except:
                    print('( 歇業中 )')
                print(stores_info['formatted_address'])
                print(stores_info['url'])

            while True:
                destination = input('請輸入目標加油站地址 (輸入 Q 退出程式): ')
                if destination in stores_name or destination in stores_address:
                    direction = gmaps.directions(location, destination, language='zh-TW')[0]['legs'][0]
                    print('預估距離: ' + str(direction['distance']['text']) + ' / 預估時間: ' + str(direction['duration']['text']))
                    layer(4)
                    break
                elif destination == 'Q':
                    sys.exit()
                else:
                    print('Error message!')
        else:
            print('===== 附近無加油站，程式結束 =====')
            sys.exit()

    if n == 4:
        a = input('是否前往並獲取路徑資訊 (Y/N): ')
        if a == 'Y':
            steps = direction['steps']
            for step in steps:
                if '<div' in str(step['html_instructions']):
                    instructions = str(step['html_instructions'])[:str(step['html_instructions']).find('<div')]
                else:
                    instructions = str(step['html_instructions'])
                print(instructions.replace('<b>', ' ').replace('</b>', ' ').replace('<wbr/>', '') + '  ( ' + str(step['distance']['text']) + ' )')
            print(findall('<div style="font-size:0.9em">(.*?)</div>', steps[len(steps)-1]['html_instructions'])[0])
            layer(5)
        elif a == 'N':
            layer(3)
        else:
            print('Error message!')
            layer(4)

    if n == 5:
        print('=== 請輸入加油資訊 ===')
        while True:
            date = input('加油日期(YYYY/MM/DD): ')
            try:
                if time.strptime(date, "%Y/%m/%d"):
                    break
            except:
                print('Error message!')
        store_ =['台灣中油', '台亞石油', '全國加油站', '福懋興業', '統一精工', '山隆通運', '台灣糖業', '北基國際', '久井企業', '千越加油站', '車容坊', '西歐加油站', '松詠', '其他']
        a = int(input('業者名稱(1. 台灣中油/2. 台亞石油/3. 全國加油站/4. 福懋興業/5. 統一精工/6. 山隆通運/7. 台灣糖業/8. 北基國際/9. 久井企業/10. 千越加油站/11. 車容坊/12. 西歐加油站/13. 松詠/14. 其他): '))
        store = store_[a - 1]
        oil_price_2 = ['台灣中油', '千越加油站', '車容坊', '山隆通運']
        if store in oil_price_2:
            n = 2
        else:
            n = 1
        while True:
            oil_ = ['98無鉛汽油', '95無鉛汽油', '92無鉛汽油', '超(高)級柴油']
            b = int(input('油種(1. 98無鉛汽油/2. 95無鉛汽油/3. 92無鉛汽油/4. 超(高)級柴油): '))
            oil = oil_[b - 1]
            if oil == '98無鉛汽油':
                price = float(tds[n * 7 + 1].text)
                break
            elif oil == '95無鉛汽油':
                price = float(tds[n * 7 + 2].text)
                break
            elif oil == '92無鉛汽油':
                price = float(tds[n * 7 + 3].text)
                break
            elif oil == '超(高)級柴油':
                price = float(tds[n * 7 + 4].text)
                break
            else:
                print('Error message!')

        while True:
            try:
                amount = float(input('加油費用: '))
                break
            except:
                print('Error message!')

        while True:
            try:
                mileage = float(input('目前里程: '))
                break
            except:
                print('Error message!')
        fill_1 = PatternFill(fill_type='solid', start_color='7FFFAA', end_color='7FFFAA')
        fill_2 = PatternFill(fill_type='solid', start_color='AAFFEE', end_color='AAFFEE')

        try:
            wb = load_workbook('Summary Table.xlsx')
            ws = wb.active

            amount_sum = 0
            a = ws.max_row
            ws.delete_rows(a)
            volume = float(amount) / float(price)
            ws.append([date, store, oil, price, amount, volume, mileage])
            ws.cell(a, 8, (float(ws.cell(a, 7).value) - float(ws.cell(a - 1, 7).value)) / volume).fill = fill_2
            for n in range(a - 1):
                amount_sum += float(ws.cell(n + 2, 5).value)
            ws.cell(a + 1, 1, 'Total').fill = fill_1
            ws.cell(a + 1, 5, amount_sum).fill = fill_1
        except:
            wb = Workbook()
            ws = wb.active

            titles = ['加油日期', '業者名稱', '油種', '油價', '加油費用', '加油量(L)', '目前里程(km)', '平均油耗(km / L)']
            col = 1
            for title in titles:
                ws.cell(1, col, title)
                col += 1
            volume = float(amount) / float(price)
            ws.append([date, store, oil, price, amount, volume, mileage, '-'*20])
            ws.cell(3, 1, 'Total').fill = fill_1
            ws.cell(3, 5, amount).fill = fill_1

        ws.column_dimensions['a'].width = 15
        ws.column_dimensions['b'].width = 15
        ws.column_dimensions['c'].width = 15
        ws.column_dimensions['g'].width = 15
        ws.column_dimensions['h'].width = 15

        wb.save("Summary Table.xlsx")
        print('\n===== 可至 Summary Table.xlsx 查看歷史加油資訊總表 =====')
        print('===================== 程式結束 ======================')


layer(1)