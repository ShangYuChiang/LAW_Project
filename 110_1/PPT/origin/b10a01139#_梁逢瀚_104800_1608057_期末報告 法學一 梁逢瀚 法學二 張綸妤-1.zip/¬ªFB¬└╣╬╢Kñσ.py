from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.remote.webelement import WebElement

from bs4 import BeautifulSoup

import time
from time import sleep

import pickle
import requests

import os
os.chdir(os.path.dirname(__file__))

my_token = 'E1koEK5mUkfmSEdeaok5FLKewEQ9K73ODMtsmUiCNqg'
def lineNotifyMessage(token, msg):

    headers = {
        "Authorization": "Bearer " + token, 
        "Content-Type" : "application/x-www-form-urlencoded"
    }

    payload = {'message': msg }
    r = requests.post("https://notify-api.line.me/api/notify", headers = headers, params = payload)
    return r.status_code

# 透過Browser Driver 開啟 Chrome
driver = webdriver.Chrome()
# 前往特定網址
default_url = "https://www.facebook.com/groups/538156889587879"
driver.get(default_url)

python_button = driver.find_element(By.CLASS_NAME, "oajrlxb2.g5ia77u1.qu0x051f.esr5mh6w.e9989ue4.r7d6kgcz.rq0escxv.nhd2j8a9.nc684nl6.p7hjln8o.kvgmc6g5.cxmmr5t8.oygrvhab.hcukyx3x.jb3vyjys.rz4wbd8a.qt6c0cv9.a8nywdso.i1ao9s8h.esuyzwwr.f1sip0of.lzcic4wl.gpro0wi8.oo9gr5id.lrazzd5p")
python_button.click()
#for i in python_button:
#    i.click()

js="window.scrollTo(0, document.body.scrollHeight-1000)"
num = 10
for x in range(num):
    driver.execute_script(js)
    time.sleep(1)

soup = BeautifulSoup(driver.page_source,"html.parser")

first=driver.find_elements(By.CLASS_NAME, "ecm0bbzt.hv4rvrfc.ihqw7lf3.dati1w0a")

#data = {}
with open('資料庫.pickle', 'rb') as f:
    data = pickle.load(f)

for i in first:
    #print(i.text)
    #print()
    if '民事訴訟法' in i.text:
        if i.text in data:
            continue
        print(i.text)
        data[i.text] = str(i)
        lineNotifyMessage(my_token,i.text)

with open('資料庫.pickle', 'wb') as f:
    pickle.dump(data, f)

driver.close()
#exit(0)
